class AccessControlManager:
    def __init__(self):
        self.roles = {}  # Dictionary to store role:permissions pairs
        self.user_roles = {}  # Dictionary to store username:role pairs

    def create_role(self, role_name, permissions):
        if role_name in self.roles:
            print(f"Role {role_name} already exists.")
            return False
        self.roles[role_name] = set(permissions)
        print(f"Role {role_name} created with permissions: {permissions}")
        return True

    def assign_role(self, username, role_name):
        if role_name not in self.roles:
            print(f"Role {role_name} does not exist.")
            return False
        self.user_roles[username] = role_name
        print(f"Role {role_name} assigned to user {username}.")
        return True

    def check_permission(self, username, permission):
        role_name = self.user_roles.get(username)
        if not role_name:
            print(f"User {username} does not have an assigned role.")
            return False
        if permission in self.roles.get(role_name, set()):
            print(f"User {username} has permission {permission}.")
            return True
        else:
            print(f"User {username} does not have permission {permission}.")
            return False
