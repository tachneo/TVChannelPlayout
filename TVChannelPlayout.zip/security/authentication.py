import hashlib

class AuthenticationManager:
    def __init__(self):
        self.users = {}  # Dictionary to store username:hashed_password pairs
        self.logged_in_user = None

    def register_user(self, username, password):
        if username in self.users:
            print(f"User {username} already exists.")
            return False
        hashed_password = self._hash_password(password)
        self.users[username] = hashed_password
        print(f"User {username} registered successfully.")
        return True

    def login(self, username, password):
        if username not in self.users:
            print(f"User {username} does not exist.")
            return False
        hashed_password = self._hash_password(password)
        if self.users[username] == hashed_password:
            self.logged_in_user = username
            print(f"User {username} logged in successfully.")
            return True
        else:
            print("Incorrect password.")
            return False

    def logout(self):
        if self.logged_in_user:
            print(f"User {self.logged_in_user} logged out successfully.")
            self.logged_in_user = None
        else:
            print("No user is currently logged in.")

    def _hash_password(self, password):
        return hashlib.sha256(password.encode()).hexdigest()
