import os

class PlaylistManager:
    def __init__(self):
        self.playlist = []

    def add_video(self, video_path):
        if os.path.exists(video_path):
            self.playlist.append(video_path)
            print(f"Added video: {video_path}")
        else:
            print(f"Video not found: {video_path}")

    def remove_video(self, video_index):
        if 0 <= video_index < len(self.playlist):
            removed_video = self.playlist.pop(video_index)
            print(f"Removed video: {removed_video}")
        else:
            print("Invalid video index.")

    def move_video(self, old_index, new_index):
        if 0 <= old_index < len(self.playlist) and 0 <= new_index < len(self.playlist):
            self.playlist.insert(new_index, self.playlist.pop(old_index))
            print(f"Moved video from index {old_index} to {new_index}.")
        else:
            print("Invalid indices for moving video.")

    def save_playlist(self, save_path):
        try:
            with open(save_path, 'w') as f:
                for video in self.playlist:
                    f.write(f"{video}\n")
            print(f"Playlist saved to {save_path}")
        except Exception as e:
            print(f"Error saving playlist: {e}")

    def load_playlist(self, load_path):
        try:
            with open(load_path, 'r') as f:
                self.playlist = [line.strip() for line in f.readlines()]
            print(f"Playlist loaded from {load_path}")
        except Exception as e:
            print(f"Error loading playlist: {e}")

    def display_playlist(self):
        print("Current Playlist:")
        for index, video in enumerate(self.playlist):
            print(f"{index + 1}: {video}")

