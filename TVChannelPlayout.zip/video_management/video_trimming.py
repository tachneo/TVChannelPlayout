import moviepy.editor as mp

class VideoTrimmer:
    def __init__(self):
        pass

    def trim_video(self, input_video_path, output_video_path, start_time, end_time):
        try:
            video = mp.VideoFileClip(input_video_path).subclip(start_time, end_time)
            video.write_videofile(output_video_path)
            print(f"Video trimmed and saved to {output_video_path}")
        except Exception as e:
            print(f"Error trimming video: {e}")

    def get_video_duration(self, video_path):
        try:
            video = mp.VideoFileClip(video_path)
            return video.duration
        except Exception as e:
            print(f"Error getting video duration: {e}")
            return None
