import moviepy.editor as mp

class WatermarkManager:
    def __init__(self):
        pass

    def add_watermark(self, video_path, watermark_path, opacity=0.5, position=("right", "bottom"), output_path="output_with_watermark.mp4"):
        try:
            video = mp.VideoFileClip(video_path)
            watermark = (mp.ImageClip(watermark_path)
                         .set_duration(video.duration)
                         .resize(height=50)  # Resize the watermark
                         .set_opacity(opacity)
                         .set_pos(position))  # Position of the watermark

            final_video = mp.CompositeVideoClip([video, watermark])
            final_video.write_videofile(output_path, codec="libx264")

            print(f"Watermark added and video saved to {output_path}")
        except Exception as e:
            print(f"Error adding watermark: {e}")
