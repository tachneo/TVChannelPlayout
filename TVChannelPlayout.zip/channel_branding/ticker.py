import moviepy.editor as mp
from moviepy.video.tools.segmenting import findObjects

class TickerManager:
    def __init__(self):
        pass

    def add_ticker(self, video_path, ticker_text, font_size=24, color='white', bg_color='black', speed=100, output_path="output_with_ticker.mp4"):
        try:
            video = mp.VideoFileClip(video_path)
            w, h = video.size

            # Create the scrolling ticker text clip
            txt_clip = mp.TextClip(ticker_text, fontsize=font_size, color=color, bg_color=bg_color)
            txt_clip = txt_clip.set_position(lambda t: ('center', h - txt_clip.size[1])) \
                .set_duration(video.duration) \
                .set_start((0, 0)) \
                .crossfadein(0.5) \
                .crossfadeout(0.5)

            # Animate the text scroll across the bottom of the screen
            ticker = txt_clip.set_pos(lambda t: (max(w - t * speed, -txt_clip.size[0]), h - txt_clip.size[1]))

            # Composite the video with the ticker
            final_video = mp.CompositeVideoClip([video, ticker])
            final_video.write_videofile(output_path, codec="libx264")

            print(f"Scrolling ticker added and video saved to {output_path}")
        except Exception as e:
            print(f"Error adding scrolling ticker: {e}")
