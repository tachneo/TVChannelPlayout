import moviepy.editor as mp
from moviepy.video.fx.all import resize

class LogoOverlay:
    def __init__(self):
        pass

    def add_logo(self, video_path, logo_path, position=("right", "top"), output_path="output_with_logo.mp4"):
        try:
            video = mp.VideoFileClip(video_path)
            logo = (mp.ImageClip(logo_path)
                    .set_duration(video.duration)
                    .resize(height=50)  # Resize the logo
                    .margin(right=8, top=8, opacity=0)  # Optional: margin/padding around the logo
                    .set_pos(position))  # Position of the logo

            final_video = mp.CompositeVideoClip([video, logo])
            final_video.write_videofile(output_path, codec="libx264")

            print(f"Logo overlay added and video saved to {output_path}")
        except Exception as e:
            print(f"Error adding logo overlay: {e}")
