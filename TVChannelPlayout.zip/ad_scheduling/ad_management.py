import os

class AdManager:
    def __init__(self):
        self.ad_playlist = []

    def add_ad(self, ad_path):
        if os.path.exists(ad_path):
            self.ad_playlist.append(ad_path)
            print(f"Added advertisement: {ad_path}")
        else:
            print(f"Advertisement not found: {ad_path}")

    def remove_ad(self, ad_index):
        if 0 <= ad_index < len(self.ad_playlist):
            removed_ad = self.ad_playlist.pop(ad_index)
            print(f"Removed advertisement: {removed_ad}")
        else:
            print("Invalid ad index.")

    def display_ads(self):
        print("Current Ad Playlist:")
        for index, ad in enumerate(self.ad_playlist):
            print(f"{index + 1}: {ad}")

    def save_ad_playlist(self, save_path):
        try:
            with open(save_path, 'w') as f:
                for ad in self.ad_playlist:
                    f.write(f"{ad}\n")
            print(f"Ad playlist saved to {save_path}")
        except Exception as e:
            print(f"Error saving ad playlist: {e}")

    def load_ad_playlist(self, load_path):
        try:
            with open(load_path, 'r') as f:
                self.ad_playlist = [line.strip() for line in f.readlines()]
            print(f"Ad playlist loaded from {load_path}")
        except Exception as e:
            print(f"Error loading ad playlist: {e}")
