import datetime

class AdScheduler:
    def __init__(self):
        self.schedule = []

    def schedule_ad(self, ad_path, play_time):
        if isinstance(play_time, datetime.datetime):
            self.schedule.append((ad_path, play_time))
            print(f"Scheduled ad '{ad_path}' at {play_time}")
        else:
            print("Invalid play time. Must be a datetime object.")

    def remove_scheduled_ad(self, index):
        if 0 <= index < len(self.schedule):
            removed_ad = self.schedule.pop(index)
            print(f"Removed scheduled ad: {removed_ad}")
        else:
            print("Invalid index.")

    def get_schedule(self):
        print("Current Ad Schedule:")
        for index, (ad, time) in enumerate(self.schedule):
            print(f"{index + 1}: {ad} scheduled at {time}")

    def save_schedule(self, save_path):
        try:
            with open(save_path, 'w') as f:
                for ad, time in self.schedule:
                    f.write(f"{ad},{time}\n")
            print(f"Ad schedule saved to {save_path}")
        except Exception as e:
            print(f"Error saving ad schedule: {e}")

    def load_schedule(self, load_path):
        try:
            with open(load_path, 'r') as f:
                self.schedule = [(line.split(',')[0], datetime.datetime.fromisoformat(line.split(',')[1].strip()))
                                 for line in f.readlines()]
            print(f"Ad schedule loaded from {load_path}")
        except Exception as e:
            print(f"Error loading ad schedule: {e}")
