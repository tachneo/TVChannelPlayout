from moviepy.editor import VideoFileClip, concatenate_videoclips

class AdInserter:
    def __init__(self):
        pass

    def insert_ad(self, video_path, ad_path, insertion_time, output_path):
        try:
            video = VideoFileClip(video_path)
            ad = VideoFileClip(ad_path)

            # Splitting the video at the insertion time
            video_part1 = video.subclip(0, insertion_time)
            video_part2 = video.subclip(insertion_time)

            # Concatenating the video parts with the ad
            final_video = concatenate_videoclips([video_part1, ad, video_part2])
            final_video.write_videofile(output_path, codec="libx264")

            print(f"Ad inserted and final video saved to {output_path}")
        except Exception as e:
            print(f"Error inserting ad: {e}")
