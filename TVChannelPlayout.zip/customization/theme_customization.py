from PyQt5.QtWidgets import qApp
from PyQt5.QtCore import QSettings

class ThemeCustomizer:
    def __init__(self):
        self.settings = QSettings("MyCompany", "TVPlayoutSystem")

    def apply_theme(self, theme_name):
        if theme_name == "Dark":
            self.set_dark_theme()
        elif theme_name == "Light":
            self.set_light_theme()
        else:
            print(f"Unknown theme: {theme_name}")

    def set_dark_theme(self):
        qApp.setStyleSheet("""
            QWidget {
                background-color: #2b2b2b;
                color: #ffffff;
            }
            QPushButton {
                background-color: #4a4a4a;
                color: #ffffff;
                border: 1px solid #555555;
                padding: 5px;
            }
            QPushButton:hover {
                background-color: #555555;
            }
            QMenuBar {
                background-color: #3c3c3c;
                color: #ffffff;
            }
        """)
        self.settings.setValue("theme", "Dark")
        print("Dark theme applied.")

    def set_light_theme(self):
        qApp.setStyleSheet("""
            QWidget {
                background-color: #ffffff;
                color: #000000;
            }
            QPushButton {
                background-color: #f0f0f0;
                color: #000000;
                border: 1px solid #cccccc;
                padding: 5px;
            }
            QPushButton:hover {
                background-color: #e0e0e0;
            }
            QMenuBar {
                background-color: #f0f0f0;
                color: #000000;
            }
        """)
        self.settings.setValue("theme", "Light")
        print("Light theme applied.")

    def load_theme(self):
        theme = self.settings.value("theme", "Light")
        self.apply_theme(theme)
