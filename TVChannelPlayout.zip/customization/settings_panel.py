from PyQt5.QtWidgets import QWidget, QVBoxLayout, QPushButton, QLabel, QComboBox
from customization.theme_customization import ThemeCustomizer

class SettingsPanel(QWidget):
    def __init__(self):
        super().__init__()

        self.theme_customizer = ThemeCustomizer()

        # Layout
        self.layout = QVBoxLayout()

        # Theme Selection
        self.theme_label = QLabel("Select Theme:")
        self.theme_combo_box = QComboBox()
        self.theme_combo_box.addItems(["Light", "Dark"])
        self.layout.addWidget(self.theme_label)
        self.layout.addWidget(self.theme_combo_box)

        # Apply Button
        self.apply_button = QPushButton("Apply Theme")
        self.layout.addWidget(self.apply_button)

        self.setLayout(self.layout)

        # Connections
        self.apply_button.clicked.connect(self.apply_theme)

    def apply_theme(self):
        selected_theme = self.theme_combo_box.currentText()
        self.theme_customizer.apply_theme(selected_theme)
