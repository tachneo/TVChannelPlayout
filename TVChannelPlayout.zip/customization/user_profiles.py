from PyQt5.QtCore import QSettings

class UserProfileManager:
    def __init__(self):
        self.settings = QSettings("MyCompany", "TVPlayoutSystem")

    def save_profile(self, profile_name):
        self.settings.setValue(f"profiles/{profile_name}/theme", self.settings.value("theme"))
        print(f"Profile '{profile_name}' saved with current settings.")

    def load_profile(self, profile_name):
        theme = self.settings.value(f"profiles/{profile_name}/theme", "Light")
        print(f"Loading profile '{profile_name}' with theme: {theme}")
        self.settings.setValue("theme", theme)
        # Here you would apply the theme and other settings
        print(f"Profile '{profile_name}' loaded.")

    def delete_profile(self, profile_name):
        self.settings.remove(f"profiles/{profile_name}")
        print(f"Profile '{profile_name}' deleted.")
