from PyQt5.QtWidgets import QMessageBox

class AlertSystem:
    def __init__(self, cpu_threshold=80, memory_threshold=80):
        self.cpu_threshold = cpu_threshold
        self.memory_threshold = memory_threshold

    def check_resources(self, cpu_usage, memory_usage):
        if cpu_usage > self.cpu_threshold:
            self.trigger_alert(f"CPU usage is high: {cpu_usage}% (Threshold: {self.cpu_threshold}%)")
        
        if memory_usage > self.memory_threshold:
            self.trigger_alert(f"Memory usage is high: {memory_usage}% (Threshold: {self.memory_threshold}%)")

    def trigger_alert(self, message):
        print(f"ALERT: {message}")
        alert = QMessageBox()
        alert.setWindowTitle("Resource Alert")
        alert.setText(message)
        alert.setIcon(QMessageBox.Warning)
        alert.exec_()
