import psutil

class MemoryMonitor:
    def __init__(self):
        pass

    def get_memory_usage(self):
        memory_info = psutil.virtual_memory()
        usage = memory_info.percent
        print(f"Current Memory Usage: {usage}%")
        return usage

    def get_swap_usage(self):
        swap_info = psutil.swap_memory()
        usage = swap_info.percent
        print(f"Current Swap Memory Usage: {usage}%")
        return usage
