import psutil

class CPUMonitor:
    def __init__(self):
        pass

    def get_cpu_usage(self):
        usage = psutil.cpu_percent(interval=1)
        print(f"Current CPU Usage: {usage}%")
        return usage

    def get_cpu_count(self):
        count = psutil.cpu_count(logical=True)
        print(f"CPU Count: {count}")
        return count
