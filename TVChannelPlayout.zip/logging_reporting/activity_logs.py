import logging

class ActivityLogger:
    def __init__(self, log_file='activity.log'):
        self.logger = logging.getLogger('ActivityLogger')
        self.logger.setLevel(logging.INFO)

        # Create a file handler that logs messages
        fh = logging.FileHandler(log_file)
        fh.setLevel(logging.INFO)

        # Create a formatter and set it for the handler
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        fh.setFormatter(formatter)

        # Add the handler to the logger
        self.logger.addHandler(fh)

    def log_activity(self, message):
        self.logger.info(message)
        print(f"Activity logged: {message}")
