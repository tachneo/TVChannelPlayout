import logging

class ErrorReporter:
    def __init__(self, log_file='error.log'):
        self.logger = logging.getLogger('ErrorReporter')
        self.logger.setLevel(logging.ERROR)

        # Create a file handler that logs error messages
        fh = logging.FileHandler(log_file)
        fh.setLevel(logging.ERROR)

        # Create a formatter and set it for the handler
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        fh.setFormatter(formatter)

        # Add the handler to the logger
        self.logger.addHandler(fh)

    def report_error(self, message):
        self.logger.error(message)
        print(f"Error reported: {message}")
