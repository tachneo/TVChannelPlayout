import os
import datetime

class PlayoutHistoryManager:
    def __init__(self, history_file='playout_history.txt'):
        self.history_file = history_file
        # Create the history file if it doesn't exist
        if not os.path.exists(self.history_file):
            with open(self.history_file, 'w') as f:
                f.write("Playout History Log\n")
                f.write("===================\n\n")

    def log_playout(self, video_name):
        with open(self.history_file, 'a') as f:
            timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            f.write(f"{timestamp} - Played: {video_name}\n")
        print(f"Playout logged: {video_name}")
