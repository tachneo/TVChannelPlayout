import subprocess
import os

class ExternalToolsIntegration:
    def __init__(self, tool_name, tool_path):
        self.tool_name = tool_name
        self.tool_path = os.path.abspath(tool_path)  # Convert to absolute path

    def execute_command(self, command_args):
        try:
            command = [self.tool_path] + command_args
            print(f"Executing command: {' '.join(command)}")
            result = subprocess.run(command, capture_output=True, text=True, check=True)
            print(f"Command output:\n{result.stdout}")
            return result.stdout
        except subprocess.CalledProcessError as e:
            print(f"Error executing {self.tool_name}: {e}")
            return None

    def check_tool_installed(self):
        try:
            result = subprocess.run([self.tool_path, '--version'], capture_output=True, text=True, check=True)
            print(f"{self.tool_name} is installed. Version info:\n{result.stdout}")
            return True
        except subprocess.CalledProcessError:
            print(f"{self.tool_name} is not installed or not found at the specified path.")
            return False
        except FileNotFoundError:
            print(f"File not found: {self.tool_path}")
            return False
