from flask import Flask, jsonify, request

class APISupport:
    def __init__(self):
        self.app = Flask(__name__)

    def start_api(self):
        @self.app.route('/')
        def index():
            return jsonify({"message": "Welcome to the TV Playout System API"})

        @self.app.route('/playout', methods=['POST'])
        def playout():
            data = request.json
            video_file = data.get("video_file")
            start_time = data.get("start_time")
            # Here you would trigger the playout functionality with the provided data
            print(f"Received playout request for video {video_file} at {start_time}")
            return jsonify({"status": "Playout started", "video_file": video_file, "start_time": start_time})

        @self.app.route('/status', methods=['GET'])
        def status():
            # Return the current status of the playout system
            status_info = {"status": "running", "current_video": "example_video.mp4"}
            return jsonify(status_info)

        print("Starting API server...")
        self.app.run(debug=True, port=5000)

    def stop_api(self):
        # This method can be expanded to stop the API server if needed
        print("API server stopped.")
