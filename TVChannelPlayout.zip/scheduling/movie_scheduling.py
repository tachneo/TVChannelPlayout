import datetime

class MovieScheduler:
    def __init__(self):
        self.schedule = []

    def schedule_movie(self, movie_path, start_time):
        if isinstance(start_time, datetime.datetime):
            self.schedule.append((movie_path, start_time))
            print(f"Scheduled movie '{movie_path}' to play at {start_time}")
        else:
            print("Invalid start time. Must be a datetime object.")

    def remove_scheduled_movie(self, index):
        if 0 <= index < len(self.schedule):
            removed_movie = self.schedule.pop(index)
            print(f"Removed scheduled movie: {removed_movie}")
        else:
            print("Invalid index.")

    def get_schedule(self):
        print("Current Movie Schedule:")
        for index, (movie, time) in enumerate(self.schedule):
            print(f"{index + 1}: {movie} scheduled at {time}")

    def save_schedule(self, save_path):
        try:
            with open(save_path, 'w') as f:
                for movie, time in self.schedule:
                    f.write(f"{movie},{time}\n")
            print(f"Movie schedule saved to {save_path}")
        except Exception as e:
            print(f"Error saving movie schedule: {e}")

    def load_schedule(self, load_path):
        try:
            with open(load_path, 'r') as f:
                self.schedule = [(line.split(',')[0], datetime.datetime.fromisoformat(line.split(',')[1].strip()))
                                 for line in f.readlines()]
            print(f"Movie schedule loaded from {load_path}")
        except Exception as e:
            print(f"Error loading movie schedule: {e}")
