import datetime
import time
from PyQt5.QtMultimedia import QMediaPlayer, QMediaContent
from PyQt5.QtCore import QUrl

class AutomatedExecutor:
    def __init__(self, media_player: QMediaPlayer, movie_schedule):
        self.media_player = media_player
        self.movie_schedule = movie_schedule

    def execute_schedule(self):
        print("Starting automated execution...")
        while self.movie_schedule:
            current_time = datetime.datetime.now()
            next_movie, next_time = self.movie_schedule[0]

            # Check if it's time to play the next movie
            if current_time >= next_time:
                self.play_movie(next_movie)
                self.movie_schedule.pop(0)  # Remove the movie from the schedule
            else:
                time_until_next_movie = (next_time - current_time).total_seconds()
                print(f"Waiting {time_until_next_movie} seconds until the next movie starts...")
                time.sleep(min(time_until_next_movie, 60))  # Sleep for up to 60 seconds at a time

    def play_movie(self, movie_path):
        self.media_player.setMedia(QUrl.fromLocalFile(movie_path))
        self.media_player.play()
        print(f"Playing movie: {movie_path}")

    def stop_execution(self):
        print("Stopping automated execution...")
        self.media_player.stop()
