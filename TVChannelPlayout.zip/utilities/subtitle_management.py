import pysrt
import moviepy.editor as mp

class SubtitleManager:
    def __init__(self):
        pass

    def add_subtitles(self, video_path, subtitle_path, output_path):
        try:
            video = mp.VideoFileClip(video_path)
            subtitles = pysrt.open(subtitle_path)

            def make_frame(t):
                subtitle = subtitles.at(t).text if subtitles.at(t) else ""
                return mp.TextClip(txt=subtitle, fontsize=24, color='white').get_frame(t)

            subtitle_clip = mp.VideoClip(make_frame, duration=video.duration)
            subtitle_clip = subtitle_clip.set_position(('center', 'bottom')).set_duration(video.duration)

            final_video = mp.CompositeVideoClip([video, subtitle_clip])
            final_video.write_videofile(output_path, codec="libx264", audio_codec='aac')
            print(f"Subtitles added and video saved to {output_path}")
        except Exception as e:
            print(f"Error adding subtitles: {e}")

    def synchronize_subtitles(self, subtitle_path, time_shift):
        try:
            subtitles = pysrt.open(subtitle_path)
            subtitles.shift(seconds=time_shift)
            subtitles.save(subtitle_path, encoding='utf-8')
            print(f"Subtitles synchronized with a shift of {time_shift} seconds.")
        except Exception as e:
            print(f"Error synchronizing subtitles: {e}")
