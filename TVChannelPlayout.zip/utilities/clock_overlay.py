import moviepy.editor as mp
from moviepy.video.tools.drawing import color_gradient
from datetime import datetime

class ClockOverlay:
    def __init__(self):
        pass

    def add_clock_overlay(self, video_path, output_path, position=("right", "top"), font_size=30, color='white'):
        try:
            video = mp.VideoFileClip(video_path)
            duration = video.duration

            def make_frame(t):
                current_time = datetime.now().strftime('%H:%M:%S')
                return mp.TextClip(txt=current_time, fontsize=font_size, color=color).get_frame(t)

            clock = mp.VideoClip(make_frame, duration=duration)
            clock = clock.set_position(position).set_duration(duration)

            final_video = mp.CompositeVideoClip([video, clock])
            final_video.write_videofile(output_path, codec="libx264", audio_codec='aac')
            print(f"Clock overlay added and video saved to {output_path}")
        except Exception as e:
            print(f"Error adding clock overlay: {e}")
