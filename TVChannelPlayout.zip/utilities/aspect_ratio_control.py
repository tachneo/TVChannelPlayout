import moviepy.editor as mp

class AspectRatioController:
    def __init__(self):
        pass

    def change_aspect_ratio(self, video_path, output_path, target_aspect_ratio):
        try:
            video = mp.VideoFileClip(video_path)
            current_aspect_ratio = video.w / video.h
            if current_aspect_ratio == target_aspect_ratio:
                print("The video already has the desired aspect ratio.")
                video.write_videofile(output_path, codec="libx264", audio_codec='aac')
                return

            if current_aspect_ratio < target_aspect_ratio:
                new_width = video.h * target_aspect_ratio
                resized_video = video.resize(width=new_width)
            else:
                new_height = video.w / target_aspect_ratio
                resized_video = video.resize(height=new_height)

            final_video = resized_video.fx(mp.vfx.crop, width=video.w, height=video.h)
            final_video.write_videofile(output_path, codec="libx264", audio_codec='aac')
            print(f"Aspect ratio changed to {target_aspect_ratio} and video saved to {output_path}")
        except Exception as e:
            print(f"Error changing aspect ratio: {e}")
