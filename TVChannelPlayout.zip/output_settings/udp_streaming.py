import subprocess

class UDPStreamer:
    def __init__(self):
        self.ffmpeg_path = "ffmpeg"  # Path to ffmpeg, make sure it's installed and in PATH

    def start_streaming(self, input_video_path, udp_url, bitrate="500k"):
        try:
            command = [
                self.ffmpeg_path,
                "-re",  # Read input at native frame rate
                "-i", input_video_path,  # Input video file
                "-c:v", "libx264",  # Video codec
                "-b:v", bitrate,  # Bitrate
                "-f", "mpegts",  # Format
                udp_url  # UDP URL
            ]
            print(f"Starting UDP streaming to {udp_url} with bitrate {bitrate}...")
            subprocess.run(command, check=True)
            print("Streaming started successfully.")
        except subprocess.CalledProcessError as e:
            print(f"Error in starting streaming: {e}")

    def stop_streaming(self):
        print("Stopping streaming...")
        # Typically, you'd need to terminate the subprocess running ffmpeg
        # This is a placeholder for stopping the streaming
        print("Streaming stopped.")
