import moviepy.editor as mp

class FileOutputManager:
    def __init__(self):
        pass

    def save_video(self, input_video_path, output_video_path, codec="libx264", format="mp4"):
        try:
            video = mp.VideoFileClip(input_video_path)
            video.write_videofile(output_video_path, codec=codec, audio_codec='aac', preset='medium', threads=4)
            print(f"Video saved to {output_video_path} with codec {codec} and format {format}.")
        except Exception as e:
            print(f"Error saving video: {e}")
