import moviepy.editor as mp

class ResolutionManager:
    def __init__(self):
        pass

    def change_resolution(self, input_video_path, output_video_path, width, height):
        try:
            video = mp.VideoFileClip(input_video_path)
            resized_video = video.resize(newsize=(width, height))
            resized_video.write_videofile(output_video_path, codec="libx264", audio_codec='aac')
            print(f"Resolution changed to {width}x{height} and video saved to {output_video_path}.")
        except Exception as e:
            print(f"Error changing resolution: {e}")
