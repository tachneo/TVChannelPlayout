from PyQt5.QtMultimedia import QMediaPlayer
from PyQt5.QtCore import QUrl

class PlaybackController:
    def __init__(self, media_player: QMediaPlayer):
        self.media_player = media_player

    def load_media(self, media_path):
        self.media_player.setMedia(QUrl.fromLocalFile(media_path))
        print(f"Loaded media: {media_path}")

    def play(self):
        self.media_player.play()
        print("Playback started")

    def pause(self):
        self.media_player.pause()
        print("Playback paused")

    def stop(self):
        self.media_player.stop()
        print("Playback stopped")

    def fast_forward(self, seconds=10):
        position = self.media_player.position() + seconds * 1000
        self.media_player.setPosition(position)
        print(f"Fast-forwarded {seconds} seconds")

    def rewind(self, seconds=10):
        position = max(self.media_player.position() - seconds * 1000, 0)
        self.media_player.setPosition(position)
        print(f"Rewinded {seconds} seconds")
