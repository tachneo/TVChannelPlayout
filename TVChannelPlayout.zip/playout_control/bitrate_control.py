from PyQt5.QtWidgets import QSlider, QLabel, QVBoxLayout, QWidget
from PyQt5.QtCore import Qt

class BitrateController(QWidget):
    def __init__(self):
        super().__init__()

        # Layout
        self.layout = QVBoxLayout()

        # Bitrate display label
        self.bitrate_label = QLabel("Current Bitrate: 500 kbps")
        self.layout.addWidget(self.bitrate_label)

        # Bitrate slider
        self.bitrate_slider = QSlider(Qt.Horizontal)
        self.bitrate_slider.setRange(100, 5000)  # Bitrate range in kbps
        self.bitrate_slider.setValue(500)
        self.layout.addWidget(self.bitrate_slider)

        self.setLayout(self.layout)

        # Connections
        self.bitrate_slider.valueChanged.connect(self.adjust_bitrate)

    def adjust_bitrate(self):
        bitrate = self.bitrate_slider.value()
        self.bitrate_label.setText(f"Current Bitrate: {bitrate} kbps")
        # Here you would add code to actually adjust the bitrate of the video stream
        print(f"Bitrate adjusted to {bitrate} kbps")
