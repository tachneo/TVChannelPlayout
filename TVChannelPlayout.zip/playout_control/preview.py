from PyQt5.QtMultimedia import QMediaPlayer, QMediaContent
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QPushButton, QLabel, QSlider, QFileDialog
from PyQt5.QtCore import Qt, QUrl

class VideoPreviewer(QWidget):
    def __init__(self):
        super().__init__()

        self.media_player = QMediaPlayer(None, QMediaPlayer.VideoSurface)

        # Layout
        self.layout = QVBoxLayout()

        # Video display label
        self.video_label = QLabel("Video Preview")
        self.video_label.setAlignment(Qt.AlignCenter)
        self.layout.addWidget(self.video_label)

        # Playback controls
        self.play_button = QPushButton("Play")
        self.pause_button = QPushButton("Pause")
        self.stop_button = QPushButton("Stop")
        self.open_button = QPushButton("Open Video")

        self.layout.addWidget(self.open_button)
        self.layout.addWidget(self.play_button)
        self.layout.addWidget(self.pause_button)
        self.layout.addWidget(self.stop_button)

        # Volume control
        self.volume_slider = QSlider(Qt.Horizontal)
        self.volume_slider.setRange(0, 100)
        self.volume_slider.setValue(50)
        self.layout.addWidget(self.volume_slider)

        self.setLayout(self.layout)

        # Connections
        self.open_button.clicked.connect(self.open_video)
        self.play_button.clicked.connect(self.media_player.play)
        self.pause_button.clicked.connect(self.media_player.pause)
        self.stop_button.clicked.connect(self.media_player.stop)
        self.volume_slider.valueChanged.connect(self.media_player.setVolume)

    def open_video(self):
        file_dialog = QFileDialog(self)
        video_path, _ = file_dialog.getOpenFileName(self, "Open Video", "", "Videos (*.mp4 *.avi *.mov *.mkv)")
        if video_path:
            self.media_player.setMedia(QMediaContent(QUrl.fromLocalFile(video_path)))
            self.video_label.setText(f"Previewing: {video_path.split('/')[-1]}")
